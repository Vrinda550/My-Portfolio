# HTML Revision Lab

A beginner-friendly, HTML-first project for revising core and professional HTML concepts through one practical webpage.

## What this project covers

- Basic HTML document structure
- Headings, paragraphs, links and images
- Same-page navigation using `href="#section-id"`
- Semantic elements: `header`, `nav`, `main`, `section`, `article`, `aside`, `footer`
- Ordered and unordered lists
- Tables with `caption`, `thead`, `tbody`, and scoped headings
- Forms, labels, input types, select, textarea, submit and reset
- Image alternative text (`alt`)
- Meta description, charset and viewport
- HTML5 audio and video (complete the TODOs)
- iframe (complete the TODO)
- Accessibility and basic SEO practices

## How to use

1. Open `index.html` in your browser.
2. Open the folder in VS Code.
3. Read the TODO comments in `index.html`.
4. Complete one challenge at a time.
5. Refresh the browser and test every link and form control.
6. Commit your progress to GitHub.

## Your practice challenges

### Challenge 1 — Navigation
- Add a `Projects` section.
- Add a link to it in the navigation.
- Make sure the link's `href` matches the section's `id`.

### Challenge 2 — Lists and links
- Add a list of five skills.
- Add one external link using `target="_blank"` and `rel="noopener noreferrer"`.

### Challenge 3 — Tables
- Add a marks table with at least three subjects.
- Try `colspan` or `rowspan`.

### Challenge 4 — Forms
- Add a date input and a radio-button group.
- Give every input a connected label.
- Test `required`, `minlength`, and `type="email"`.

### Challenge 5 — Media and iframe
- Add your own audio and video files, with `controls`.
- Add an iframe with a useful `title`.
- Only embed content from a source that permits embedding.

### Challenge 6 — Accessibility
- Check that every meaningful image has useful `alt` text.
- Use headings in a logical order.
- Navigate the page using only the keyboard.
- Make sure form fields have labels.

### Challenge 7 — DOM preview
- Add a small JavaScript file later.
- Select one element by ID and change its text after a button click.
- Keep this as a separate next step after your HTML revision.

## Suggested GitHub commit plan

Make small commits as you complete each task:

```bash
git add .
git commit -m "Create HTML revision lab structure"

git add .
git commit -m "Add semantic sections and navigation"

git add .
git commit -m "Practise tables and lists"

git add .
git commit -m "Build accessible contact form"

git add .
git commit -m "Add HTML5 media and iframe"

git push
```

For the first push, create an empty repository on GitHub, then follow the repository's instructions to connect your local folder. Common commands are:

```bash
git init
git add .
git commit -m "Initial HTML revision lab"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_REPOSITORY_URL` with the URL of your own GitHub repository.

## Before you publish

- Replace `Your Name` and the sample education details.
- Remove or replace the placeholder image.
- Do not upload private information, passwords or API keys.
- Test the page in a browser.
- Update this README as you learn.
